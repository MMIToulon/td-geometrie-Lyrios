<?php
require_once('Produit.php');
class Unite extends Produit{

	public function __construct(){
		echo "Creation d'un produit ";
		parent::__construct();
	}

 	public function __toString(){
 		$text = "<hr> Unite ".
 				"<br> nombre de produits :".$this->nombreProduit.
 				"<br> prix à l'unite :".$this->prixUnite."<hr>";
 		return $text;
 	}

 	public function calculPrix(){
 		return floor($this->nombreProduit*$this->prixUnite);
 	}	
}
?>


