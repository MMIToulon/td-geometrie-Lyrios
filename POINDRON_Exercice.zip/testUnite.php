<?php

	require_once("src/Unite.php");

	$d = new Unite();
	echo $d;
	
	$prix = $d->calcul_Prix();	
	echo "<br>le prix est ".$prix;
	echo "<br> Le nombre de produits crees est :".Produit::$compteur;

?>